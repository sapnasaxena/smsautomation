package com.qa.tests.api.common;

public class APICommon {

}
