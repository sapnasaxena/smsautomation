package com.qa.tests.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.qa.tests.ui.common.BasePage;


public class PatientProfile extends BasePage {

	public PatientProfile(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	public String patientNameLocator ="//tr[1]/td[1]";
	public String getPatientNameLocator()
	{
		return patientNameLocator;
	}
	
	public String overviewTab = "//a[contains(text(),'Overview')]";
	public String getOverviewTab()
	{
		return overviewTab;
	}
	
	public String appointmentsTab = "//a[contains(text(),'Appointments')]";
	public String getappointmentsTab()
	{
		return appointmentsTab;
	}
	
	public String casesTab = "//a[contains(text(),'Cases')]";
	public String getCasesTab()
	{
		return casesTab;
	}
	
	public String paymentsTab = "//a[contains(text(),'Payments')]";
	public String getPaymentsTab()
	{
		return paymentsTab;
	}
	
	public String notesTab = "//a[contains(text(),'Notes')]";
	public String getNotesTab()
	{
		return notesTab;
	}
	
	public String smsTab = "//a[contains(text(),'Sms')]";
	public String getSMSTab()
	{
		return smsTab;
	}
	
	public String vitalsTab = "//a[contains(text(),'Vitals')]";
	public String getVitalsTab()
	{
		return vitalsTab;
	}
	
	public String familyTab = "//a[contains(text(),'Family')]";
	public String getFamilyTab()
	{
		return familyTab;
	}
	
	public String ticketTab = "//a[contains(text(),'Ticket')]";
	public String getTicketTab()
	{
		return ticketTab;
	}
	
	public String requestPaymentTab = "//a[contains(text(),'Request Payment')]";
	public String getrequestPaymentTab()
	{
		return requestPaymentTab;
	}
	
	public String ordersTab = "//a[contains(text(),'Orders')]";
	public String getOrdersTab()
	{
		return ordersTab;
	}
	
	public void onClickPatientName()
	{
		driver.findElement(By.xpath(patientNameLocator)).click();
	}
	

}
