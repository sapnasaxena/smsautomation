package com.qa.tests.ui.tests;

public class PaymentTest {

	public PaymentTest() {
		// TODO Auto-generated constructor stub
	}

}
