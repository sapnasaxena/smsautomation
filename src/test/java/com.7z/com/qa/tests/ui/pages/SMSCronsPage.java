package com.qa.tests.ui.pages;

import org.openqa.selenium.WebDriver;

import com.qa.tests.ui.common.BasePage;

public class SMSCronsPage extends BasePage{

	public SMSCronsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	
}
