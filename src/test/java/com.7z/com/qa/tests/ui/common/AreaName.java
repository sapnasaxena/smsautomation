package com.qa.tests.ui.common;

import com.qa.tests.common.GlobalConstants.AREA;

public class AreaName {
	
	private AREA areaName;

	public AREA getAreaName() {
		return areaName;
	}

	public AREA setAreaName(AREA areaName) {
		return this.areaName = areaName;
	}

}
