package com.qa.tests.ui.pages;



public class PaymentPage {

	public PaymentPage() {
		// TODO Auto-generated constructor stub
	}

	
	
}
