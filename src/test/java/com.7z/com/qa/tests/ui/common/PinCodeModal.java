package com.qa.tests.ui.common;

public class PinCodeModal {

	 
}
